package main

import "github.com/kinvolk/go-shamir/cli/cmd"

func main() {
	cmd.Execute()
}
